package com.example.autori;

public class Autor {
// todo
//        Autor ima sljedece atribute:
//      Ime
//      Prezime
//      Broj objavljenih knjiga
//      Najprodavanija knjiga
//      Broj prodatih komada najprodavanije knjige
//
//    Klasa treba da ima prazan konstruktor kao i getere i setere
}
