package com.example.autori;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        // ToDo: pristupiti RecyclerView-u, kreirati LayouManager i adapter, postaviti adapter na recyclerView
        // ToDo: kreirati listu autora i poslati tu listu adapteru
    }
}
