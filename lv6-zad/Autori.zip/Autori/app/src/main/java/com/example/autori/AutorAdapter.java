package com.example.autori;

public class AutorAdapter {
    // todo: extends RecyclerView.Adapter....

}
